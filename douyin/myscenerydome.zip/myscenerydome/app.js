
/*---------------------------------------------------------------------------------------------
 *  Copyright (c) ByteDance Corporation. All rights reserved.
 *  Licensed under the MIT License. See License.txt in the project root for license information.
 *--------------------------------------------------------------------------------------------*/
App({
	onLaunch: function () {
	
	},
	onShow: function (options) {
		// Do something when show.
	},
})
